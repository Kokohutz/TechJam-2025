**To create a Client-Side SSL Certificate**

Command::

  aws apigateway generate-client-certificate --description 'My First Client Certificate'
